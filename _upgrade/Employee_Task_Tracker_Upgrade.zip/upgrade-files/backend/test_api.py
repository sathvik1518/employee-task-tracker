"""Automated tests for the API.

Run (from the backend folder, with the venv on):
    pip install pytest httpx
    $env:DB_NAME="task_tracker_test"      # use a separate test database, not your real data
    python -m pytest -q

Do NOT run these against your Neon DATABASE_URL: the tests empty the tables first.
"""
import os
from datetime import date, timedelta

import pytest
from fastapi.testclient import TestClient

if os.getenv("DATABASE_URL"):
    raise SystemExit("Refusing to run tests against DATABASE_URL (they clear all rows). Unset it first.")

import db
from main import app


@pytest.fixture()
def client():
    with TestClient(app) as c:  # runs startup: creates the database and tables
        db.run("TRUNCATE tasks, employees RESTART IDENTITY CASCADE", fetch=None)
        yield c


def make_employee(client, name="Asha Rao", email="asha@example.com", department="Engineering"):
    r = client.post("/employees", json={"name": name, "email": email, "department": department})
    assert r.status_code == 201, r.text
    return r.json()


def make_task(client, employee_id, **overrides):
    body = {
        "title": "Write report",
        "description": "Quarterly numbers",
        "priority": "High",
        "due_date": str(date.today() + timedelta(days=2)),
        "employee_id": employee_id,
    }
    body.update(overrides)
    r = client.post("/tasks", json=body)
    assert r.status_code == 201, r.text
    return r.json()


# ---------------- employees ----------------
def test_add_list_employee(client):
    e = make_employee(client)
    assert e["task_count"] == 0
    rows = client.get("/employees").json()
    assert [r["email"] for r in rows] == ["asha@example.com"]


def test_duplicate_email_is_409(client):
    make_employee(client)
    r = client.post("/employees", json={"name": "Other", "email": "asha@example.com", "department": "HR"})
    assert r.status_code == 409


def test_invalid_email_is_422(client):
    r = client.post("/employees", json={"name": "Bad", "email": "nope", "department": "HR"})
    assert r.status_code == 422


def test_edit_employee(client):
    e = make_employee(client)
    r = client.put(f"/employees/{e['id']}", json={"name": "Asha R", "email": "asha@example.com", "department": "Design"})
    assert r.status_code == 200
    assert r.json()["department"] == "Design"


def test_edit_employee_to_taken_email_is_409(client):
    make_employee(client)
    b = make_employee(client, name="Bala", email="bala@example.com")
    r = client.put(f"/employees/{b['id']}", json={"name": "Bala", "email": "asha@example.com", "department": "HR"})
    assert r.status_code == 409


def test_edit_missing_employee_is_404(client):
    r = client.put("/employees/999", json={"name": "Ghost", "email": "g@example.com", "department": "HR"})
    assert r.status_code == 404


def test_search_and_department_filter(client):
    make_employee(client)
    make_employee(client, name="Bala Menon", email="bala@example.com", department="Sales")
    assert len(client.get("/employees", params={"search": "bala"}).json()) == 1
    assert len(client.get("/employees", params={"department": "Sales"}).json()) == 1
    assert len(client.get("/employees", params={"search": "%"}).json()) == 0  # % is not a wildcard


def test_delete_employee_removes_tasks(client):
    e = make_employee(client)
    make_task(client, e["id"])
    assert client.delete(f"/employees/{e['id']}").status_code == 200
    assert client.get("/tasks").json() == []
    assert client.delete(f"/employees/{e['id']}").status_code == 404


# ---------------- tasks ----------------
def test_create_task_with_employee_name(client):
    e = make_employee(client)
    t = make_task(client, e["id"])
    assert t["employee_name"] == "Asha Rao"
    assert t["status"] == "Pending"
    assert t["is_overdue"] is False


def test_task_for_missing_employee_is_400(client):
    r = client.post("/tasks", json={"title": "Orphan", "priority": "Low", "due_date": "2030-01-01", "employee_id": 42})
    assert r.status_code == 400


def test_status_update_and_validation(client):
    e = make_employee(client)
    t = make_task(client, e["id"])
    ok = client.patch(f"/tasks/{t['id']}/status", json={"status": "Completed"})
    assert ok.status_code == 200 and ok.json()["status"] == "Completed"
    assert client.patch(f"/tasks/{t['id']}/status", json={"status": "Done"}).status_code == 422
    assert client.patch("/tasks/999/status", json={"status": "Pending"}).status_code == 404


def test_edit_task(client):
    a = make_employee(client)
    b = make_employee(client, name="Bala", email="bala@example.com")
    t = make_task(client, a["id"])
    body = {"title": "New title", "description": "", "priority": "Low", "status": "In Progress",
            "due_date": "2031-05-05", "employee_id": b["id"]}
    r = client.put(f"/tasks/{t['id']}", json=body)
    assert r.status_code == 200
    data = r.json()
    assert (data["title"], data["employee_name"], data["status"]) == ("New title", "Bala", "In Progress")


def test_delete_task(client):
    e = make_employee(client)
    t = make_task(client, e["id"])
    assert client.delete(f"/tasks/{t['id']}").status_code == 200
    assert client.delete(f"/tasks/{t['id']}").status_code == 404


def test_overdue_flag_and_filters(client):
    e = make_employee(client)
    past = str(date.today() - timedelta(days=30))
    make_task(client, e["id"], title="Old task", due_date=past)
    done = make_task(client, e["id"], title="Old but done", due_date=past, status="Completed")
    make_task(client, e["id"], title="Future task", priority="Low")

    assert done["is_overdue"] is False  # completed tasks are never overdue
    assert [t["title"] for t in client.get("/tasks", params={"overdue": True}).json()] == ["Old task"]
    assert len(client.get("/tasks", params={"status": "Completed"}).json()) == 1
    assert len(client.get("/tasks", params={"priority": "Low"}).json()) == 1
    assert len(client.get("/tasks", params={"employee_id": e["id"]}).json()) == 3
    assert len(client.get("/tasks", params={"search": "asha"}).json()) == 3  # matches employee name
    assert len(client.get("/tasks", params={"search": "future"}).json()) == 1


# ---------------- dashboard ----------------
def test_dashboard_counts(client):
    e = make_employee(client)
    past = str(date.today() - timedelta(days=5))
    make_task(client, e["id"], due_date=past)
    make_task(client, e["id"], status="In Progress")
    make_task(client, e["id"], status="Completed")
    d = client.get("/dashboard").json()
    assert d["total_employees"] == 1
    assert d["total_tasks"] == 3
    assert d["completed_tasks"] == 1
    assert d["pending_tasks"] == 1
    assert d["in_progress_tasks"] == 1
    assert d["overdue_tasks"] == 1
    assert d["completion_rate"] == 33
    assert d["workload"][0]["name"] == "Asha Rao"
    assert sum(x["count"] for x in d["due_by_date"]) == 2  # open tasks only
    assert d["attention"][0]["is_overdue"] is True


def test_dashboard_empty_database(client):
    d = client.get("/dashboard").json()
    assert d["total_tasks"] == 0 and d["completion_rate"] == 0
    assert d["attention"] == [] and d["workload"] == []
