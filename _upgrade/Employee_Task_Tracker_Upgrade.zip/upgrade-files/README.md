# Employee Task Tracker

A team workspace to manage employees and the tasks assigned to them.
React frontend, FastAPI backend, PostgreSQL database (Neon in the cloud).

**Live app:** https://employee-task-tracker-omega-eight.vercel.app

## What it does

**Employees**
- Add, edit and delete employees (name, email, department)
- Search by name or email, filter by department
- Each card shows open, completed and overdue task counts
- Deleting an employee also deletes their tasks (the confirm box tells you how many)

**Tasks**
- Create and edit tasks (title, description, priority, due date, assignee, status)
- Assign each task to an employee; the list always shows the employee's name
- Update status (Pending, In Progress, Completed) from a Kanban board (drag and drop) or from a list
- Delete a task, with an Undo button
- Search by task or employee name, filter by status, priority, employee or overdue
- Sort the list, export the tasks on screen to CSV
- Overdue tasks are flagged automatically

**Dashboard**
- Total employees, total tasks, completed, in progress and pending counts
- Overdue count, completion rate, open tasks by due date (line chart), workload per employee, open tasks by priority, and a "needs attention" list

**Also:** dark mode (remembered), works on phones, toast messages, clear error messages, loading placeholders.

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | React 18, Vite, plain CSS (no UI library) |
| Backend | Python FastAPI, Pydantic validation, psycopg2 (raw SQL with `%s` placeholders) |
| Database | PostgreSQL on Neon |
| Hosting | Vercel (frontend and API in one project) |

## Database

Two tables, one relationship: one employee has many tasks.

- `employees`: id (primary key), name, email (unique), department, created_at
- `tasks`: id (primary key), title, description, priority, status, due_date, employee_id, created_at
- `tasks.employee_id` is a foreign key to `employees.id` with `ON DELETE CASCADE`
- CHECK rules allow only Low / Medium / High priority and Pending / In Progress / Completed status

The database does the counting for the dashboard (`COUNT(*) FILTER (WHERE ...)`) and the search and filters, not the browser.

## API

Open `/docs` on the backend for Swagger. On the live site every path starts with `/api`.

| Method | Path | Purpose |
|---|---|---|
| GET | `/employees?search=&department=` | List employees with task counts |
| POST | `/employees` | Add an employee (409 if the email exists) |
| PUT | `/employees/{id}` | Edit an employee |
| DELETE | `/employees/{id}` | Delete an employee and their tasks |
| GET | `/tasks?search=&status=&priority=&employee_id=&overdue=` | List and filter tasks |
| POST | `/tasks` | Create a task (400 if the employee does not exist) |
| PUT | `/tasks/{id}` | Edit a task |
| PATCH | `/tasks/{id}/status` | Change only the status |
| DELETE | `/tasks/{id}` | Delete a task |
| GET | `/dashboard` | Counts, completion rate, charts data, attention list |

Invalid input returns 422, a missing record 404, a duplicate email 409.

## Run it locally (Windows, PowerShell)

You need Python 3.11+, Node.js 18+ and a PostgreSQL database. Use a free Neon database, or a local PostgreSQL.

**Terminal 1: backend**
```
cd backend
python -m venv ..\venv          # first time only
..\venv\Scripts\activate
pip install -r requirements.txt  # first time only
$env:DATABASE_URL="your-neon-connection-string"
python -m uvicorn main:app --reload --port 8000
```
Wait for `Database ready.` The tables are created automatically.

**Terminal 2: frontend**
```
cd frontend
npm install                      # first time only
npm run dev
```
Open http://localhost:5173

Never commit your connection string. It is read from the `DATABASE_URL` environment variable.

## Tests

The API has automated tests. They empty the tables first, so use a separate local test database, never your Neon one.
```
cd backend
pip install pytest httpx
$env:DATABASE_URL=""             # make sure the cloud database is not used
$env:DB_NAME="task_tracker_test"
python -m pytest -q
```

## Deploy

Push to GitHub. Vercel builds the React app and the FastAPI function from `vercel.json`.
Set the `DATABASE_URL` environment variable in Vercel (Settings, Environment Variables).
"Overdue" follows the `APP_TIMEZONE` setting (default `Asia/Kolkata`).

## Project structure

```
api/index.py          Vercel entry point (serves the backend under /api)
backend/main.py       All API endpoints
backend/db.py         Database connection and query helpers
backend/schema.sql    Table definitions
backend/test_api.py   Automated API tests
frontend/src/         React app (App, api.js, components/, styles.css)
vercel.json           Vercel settings
```
